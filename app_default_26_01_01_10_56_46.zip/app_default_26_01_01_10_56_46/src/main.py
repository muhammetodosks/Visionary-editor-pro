import os
import sys
import threading
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from core.app_controller import AppController
from core.crash_containment import CrashContainment, ErrorSeverity
from ui.framework import UIFramework


def setup_environment():
    """Initialize environment variables and paths."""
    env_file = Path(__file__).parent.parent / '.env'
    if env_file.exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)
    
    os.environ.setdefault('APP_THEME', 'cyberpunk')
    os.environ.setdefault('APP_FPS_MAX', '120')
    os.environ.setdefault('APP_FPS_MIN', '30')
    os.environ.setdefault('ENABLE_HARDWARE_MONITORING', 'True')
    os.environ.setdefault('ENABLE_VISION_PROCESSING', 'True')
    os.environ.setdefault('ENABLE_AI_INFERENCE', 'False')
    os.environ.setdefault('PERFORMANCE_MODE', 'NORMAL')
    os.environ.setdefault('CRASH_LOG_SIZE', '50')
    os.environ.setdefault('EVENT_QUEUE_SIZE', '1000')
    os.environ.setdefault('LOG_LEVEL', 'INFO')
    os.environ.setdefault('DEBUG_MODE', 'False')


def main():
    """Main entry point for the application."""
    setup_environment()
    
    crash_containment = CrashContainment(
        max_history=int(os.environ.get('CRASH_LOG_SIZE', 50))
    )
    
    try:
        ui_framework = UIFramework()
        app_controller = AppController(
            ui_framework=ui_framework,
            crash_containment=crash_containment
        )
        
        app_controller.initialize()
        app_controller.run()
        
    except Exception as e:
        crash_containment.capture_error(
            error=e,
            severity=ErrorSeverity.CRITICAL,
            context="Main Thread"
        )
        print(f"Critical Error: {e}")
        crash_containment.print_history()
        sys.exit(1)


if __name__ == "__main__":
    main()
