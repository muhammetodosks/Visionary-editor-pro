import threading
import time
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
import logging


logger = logging.getLogger(__name__)


class BaseEngine(ABC):
    """Base class for all engines."""
    
    def __init__(self, name: str, event_dispatcher, update_interval: float = 0.1):
        """Initialize base engine.
        
        Args:
            name: Engine name
            event_dispatcher: Event dispatcher instance
            update_interval: Update interval in seconds
        """
        self.name = name
        self.event_dispatcher = event_dispatcher
        self.update_interval = update_interval
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.lock = threading.RLock()
        self.stats = {
            'updates': 0,
            'errors': 0,
            'last_update': 0.0
        }
    
    def start(self):
        """Start engine."""
        if self.running:
            return
        
        self.running = True
        self.thread = threading.Thread(
            target=self._run,
            daemon=True,
            name=f"Engine-{self.name}"
        )
        self.thread.start()
        logger.info(f"Engine '{self.name}' started")
    
    def stop(self):
        """Stop engine."""
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)
        logger.info(f"Engine '{self.name}' stopped")
    
    def _run(self):
        """Engine main loop."""
        while self.running:
            try:
                self.update()
                with self.lock:
                    self.stats['updates'] += 1
                time.sleep(self.update_interval)
            except Exception as e:
                logger.error(f"Error in engine '{self.name}': {e}")
                with self.lock:
                    self.stats['errors'] += 1
    
    @abstractmethod
    def update(self):
        """Update engine state. Must be implemented by subclasses."""
        pass
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics.
        
        Returns:
            Statistics dictionary
        """
        with self.lock:
            return self.stats.copy()
    
    def emit_event(self, event_name: str, data: Any = None):
        """Emit event through dispatcher.
        
        Args:
            event_name: Event name
            data: Event data
        """
        if self.event_dispatcher:
            self.event_dispatcher.emit(f"{self.name}:{event_name}", data)
