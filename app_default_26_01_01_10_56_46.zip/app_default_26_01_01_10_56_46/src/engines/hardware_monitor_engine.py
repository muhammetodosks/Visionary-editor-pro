import psutil
import platform
from typing import Dict, Any
from core_engine import BaseEngine


class HardwareMonitorEngine(BaseEngine):
    """Hardware monitoring engine."""
    
    def __init__(self, event_dispatcher):
        """Initialize hardware monitor engine.
        
        Args:
            event_dispatcher: Event dispatcher instance
        """
        super().__init__("HardwareMonitor", event_dispatcher, update_interval=1.0)
        self.last_data = {}
    
    def update(self):
        """Update hardware metrics."""
        try:
            data = {
                'timestamp': 0,
                'cpu_percent': psutil.cpu_percent(interval=0.1),
                'memory': self._get_memory_info(),
                'disk': self._get_disk_info(),
                'network': self._get_network_info(),
                'system': self._get_system_info()
            }
            
            # Emit only if data changed significantly
            if self._data_changed(data):
                self.emit_event('metrics_updated', data)
                self.last_data = data
            
        except Exception as e:
            logger.error(f"Error updating hardware metrics: {e}")
    
    def _get_memory_info(self) -> Dict[str, Any]:
        """Get memory information."""
        try:
            memory = psutil.virtual_memory()
            return {
                'total': memory.total,
                'available': memory.available,
                'percent': memory.percent,
                'used': memory.used
            }
        except Exception:
            return {}
    
    def _get_disk_info(self) -> Dict[str, Any]:
        """Get disk information."""
        try:
            disk = psutil.disk_usage('/')
            return {
                'total': disk.total,
                'used': disk.used,
                'free': disk.free,
                'percent': disk.percent
            }
        except Exception:
            return {}
    
    def _get_network_info(self) -> Dict[str, Any]:
        """Get network information."""
        try:
            net = psutil.net_if_stats()
            return {
                'interfaces': len(net),
                'stats': {name: {'up': stats.isup} for name, stats in net.items()}
            }
        except Exception:
            return {}
    
    def _get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        try:
            return {
                'platform': platform.system(),
                'platform_release': platform.release(),
                'processor_count': psutil.cpu_count(),
                'boot_time': psutil.boot_time()
            }
        except Exception:
            return {}
    
    def _data_changed(self, data: Dict[str, Any]) -> bool:
        """Check if data changed significantly.
        
        Args:
            data: New data
            
        Returns:
            True if data changed significantly
        """
        if not self.last_data:
            return True
        
        if abs(data.get('cpu_percent', 0) - self.last_data.get('cpu_percent', 0)) > 5:
            return True
        
        mem_current = data.get('memory', {}).get('percent', 0)
        mem_last = self.last_data.get('memory', {}).get('percent', 0)
        if abs(mem_current - mem_last) > 3:
            return True
        
        return False
