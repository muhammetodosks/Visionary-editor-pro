import threading
from typing import Dict, Tuple, Optional, Any
from dataclasses import dataclass


@dataclass
class Color:
    """RGBA color."""
    r: int
    g: int
    b: int
    a: int = 255
    
    def to_tuple(self) -> Tuple[int, int, int, int]:
        """Convert to tuple."""
        return (self.r, self.g, self.b, self.a)
    
    def to_rgb(self) -> Tuple[int, int, int]:
        """Convert to RGB tuple."""
        return (self.r, self.g, self.b)


class ThemeManager:
    """Application theme management system."""
    
    def __init__(self):
        """Initialize theme manager."""
        self.current_theme = "cyberpunk"
        self.lock = threading.RLock()
        
        self.themes: Dict[str, Dict[str, Any]] = {
            'cyberpunk': self._create_cyberpunk_theme(),
            'arctic': self._create_arctic_theme(),
            'sunset': self._create_sunset_theme()
        }
    
    def _create_cyberpunk_theme(self) -> Dict[str, Any]:
        """Create cyberpunk theme."""
        return {
            'name': 'Cyberpunk',
            'background': (20, 20, 30),
            'primary': (255, 0, 255),
            'secondary': (0, 255, 255),
            'accent': (255, 255, 0),
            'text': (255, 255, 255),
            'text_dark': (150, 150, 150),
            'border': (255, 0, 255),
            'success': (0, 255, 100),
            'error': (255, 0, 50),
            'warning': (255, 150, 0),
            'info': (0, 200, 255),
            'panel': (30, 30, 45),
            'hover': (255, 0, 255, 50),
            'active': (255, 0, 255, 100)
        }
    
    def _create_arctic_theme(self) -> Dict[str, Any]:
        """Create arctic theme."""
        return {
            'name': 'Arctic',
            'background': (230, 245, 255),
            'primary': (0, 120, 200),
            'secondary': (100, 180, 255),
            'accent': (0, 200, 200),
            'text': (40, 40, 60),
            'text_dark': (100, 100, 120),
            'border': (0, 120, 200),
            'success': (0, 180, 100),
            'error': (220, 50, 80),
            'warning': (255, 140, 0),
            'info': (0, 150, 200),
            'panel': (240, 250, 255),
            'hover': (200, 230, 255, 100),
            'active': (150, 200, 255, 150)
        }
    
    def _create_sunset_theme(self) -> Dict[str, Any]:
        """Create sunset theme."""
        return {
            'name': 'Sunset',
            'background': (50, 30, 25),
            'primary': (255, 100, 50),
            'secondary': (255, 150, 80),
            'accent': (255, 200, 100),
            'text': (255, 245, 240),
            'text_dark': (200, 160, 140),
            'border': (255, 100, 50),
            'success': (100, 200, 100),
            'error': (255, 80, 60),
            'warning': (255, 160, 50),
            'info': (150, 180, 255),
            'panel': (60, 40, 35),
            'hover': (255, 100, 50, 50),
            'active': (255, 100, 50, 100)
        }
    
    def set_theme(self, theme_name: str) -> bool:
        """Set application theme.
        
        Args:
            theme_name: Name of theme to set
            
        Returns:
            True if theme was set successfully
        """
        with self.lock:
            if theme_name not in self.themes:
                return False
            
            self.current_theme = theme_name
            return True
    
    def get_current_theme(self) -> Dict[str, Any]:
        """Get current theme.
        
        Returns:
            Current theme dictionary
        """
        with self.lock:
            return self.themes[self.current_theme].copy()
    
    def get_theme(self, theme_name: str) -> Optional[Dict[str, Any]]:
        """Get specific theme.
        
        Args:
            theme_name: Name of theme
            
        Returns:
            Theme dictionary or None if not found
        """
        with self.lock:
            if theme_name in self.themes:
                return self.themes[theme_name].copy()
            return None
    
    def get_color(self, color_key: str) -> Tuple[int, int, int]:
        """Get color from current theme.
        
        Args:
            color_key: Color key name
            
        Returns:
            RGB tuple
        """
        with self.lock:
            theme = self.themes[self.current_theme]
            color = theme.get(color_key, (255, 255, 255))
            
            if isinstance(color, tuple) and len(color) == 4:
                return color[:3]
            return color
    
    def get_available_themes(self) -> list:
        """Get list of available themes.
        
        Returns:
            List of theme names
        """
        with self.lock:
            return list(self.themes.keys())
