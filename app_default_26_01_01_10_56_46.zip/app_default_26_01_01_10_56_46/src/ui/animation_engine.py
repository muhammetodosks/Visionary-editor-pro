import time
import math
from typing import Dict, List, Optional, Callable, Any
from enum import Enum
from dataclasses import dataclass
import threading


class EasingFunction(Enum):
    """Easing function types."""
    LINEAR = "linear"
    EASE_IN_QUAD = "ease_in_quad"
    EASE_OUT_QUAD = "ease_out_quad"
    EASE_IN_OUT_QUAD = "ease_in_out_quad"
    EASE_IN_CUBIC = "ease_in_cubic"
    EASE_OUT_CUBIC = "ease_out_cubic"
    EASE_IN_SINE = "ease_in_sine"
    EASE_OUT_SINE = "ease_out_sine"
    BOUNCE = "bounce"
    ELASTIC = "elastic"


@dataclass
class Animation:
    """Animation definition."""
    target: Any
    property: str
    start_value: float
    end_value: float
    duration: float
    easing: EasingFunction
    on_complete: Optional[Callable] = None
    start_time: float = None
    is_playing: bool = True
    
    def __post_init__(self):
        if self.start_time is None:
            self.start_time = time.time()


class AnimationEngine:
    """Frame-based animation engine."""
    
    def __init__(self):
        """Initialize animation engine."""
        self.animations: List[Animation] = []
        self.lock = threading.RLock()
        self.stats = {
            'total_animations': 0,
            'active_animations': 0,
            'completed_animations': 0
        }
    
    def animate(self, target: Any, property: str, end_value: float,
               duration: float = 1.0, easing: EasingFunction = EasingFunction.LINEAR,
               on_complete: Optional[Callable] = None) -> Animation:
        """Create and start animation.
        
        Args:
            target: Object to animate
            property: Property name to animate
            end_value: Target value
            duration: Animation duration in seconds
            easing: Easing function
            on_complete: Callback when animation completes
            
        Returns:
            Animation object
        """
        try:
            start_value = getattr(target, property, 0)
            
            animation = Animation(
                target=target,
                property=property,
                start_value=start_value,
                end_value=end_value,
                duration=duration,
                easing=easing,
                on_complete=on_complete
            )
            
            with self.lock:
                self.animations.append(animation)
                self.stats['total_animations'] += 1
                self.stats['active_animations'] = len(self.animations)
            
            return animation
        
        except Exception as e:
            raise RuntimeError(f"Error creating animation: {e}")
    
    def update(self, dt: float):
        """Update all active animations.
        
        Args:
            dt: Delta time since last frame
        """
        current_time = time.time()
        completed = []
        
        with self.lock:
            for animation in self.animations:
                if not animation.is_playing:
                    continue
                
                elapsed = current_time - animation.start_time
                progress = min(elapsed / animation.duration, 1.0)
                
                # Apply easing
                eased_progress = self._apply_easing(progress, animation.easing)
                
                # Calculate value
                value = animation.start_value + (animation.end_value - animation.start_value) * eased_progress
                
                # Set property
                try:
                    setattr(animation.target, animation.property, value)
                except Exception:
                    pass
                
                # Check if complete
                if progress >= 1.0:
                    animation.is_playing = False
                    completed.append(animation)
        
        # Remove completed animations
        with self.lock:
            for animation in completed:
                if animation in self.animations:
                    self.animations.remove(animation)
                    self.stats['completed_animations'] += 1
                    self.stats['active_animations'] = len(self.animations)
        
        # Execute callbacks
        for animation in completed:
            try:
                if animation.on_complete:
                    animation.on_complete()
            except Exception:
                pass
    
    def _apply_easing(self, t: float, easing: EasingFunction) -> float:
        """Apply easing function.
        
        Args:
            t: Time progress (0 to 1)
            easing: Easing function type
            
        Returns:
            Eased progress value
        """
        t = max(0, min(t, 1.0))
        
        if easing == EasingFunction.LINEAR:
            return t
        
        elif easing == EasingFunction.EASE_IN_QUAD:
            return t * t
        
        elif easing == EasingFunction.EASE_OUT_QUAD:
            return t * (2 - t)
        
        elif easing == EasingFunction.EASE_IN_OUT_QUAD:
            return 2 * t * t if t < 0.5 else -1 + (4 - 2 * t) * t
        
        elif easing == EasingFunction.EASE_IN_CUBIC:
            return t * t * t
        
        elif easing == EasingFunction.EASE_OUT_CUBIC:
            t = t - 1
            return t * t * t + 1
        
        elif easing == EasingFunction.EASE_IN_SINE:
            return 1 - math.cos((t * math.pi) / 2)
        
        elif easing == EasingFunction.EASE_OUT_SINE:
            return math.sin((t * math.pi) / 2)
        
        elif easing == EasingFunction.BOUNCE:
            if t < 0.5:
                return 4 * t * t * t
            else:
                t = 2 * t - 2
                return 0.5 * t * t * t + 1
        
        elif easing == EasingFunction.ELASTIC:
            if t == 0 or t == 1:
                return t
            p = 0.3
            s = p / 4
            t = t - 1
            return -(2 ** (10 * t)) * math.sin((t - s) * (2 * math.pi) / p)
        
        return t
    
    def stop_animation(self, animation: Animation):
        """Stop specific animation.
        
        Args:
            animation: Animation to stop
        """
        with self.lock:
            animation.is_playing = False
    
    def stop_all(self):
        """Stop all animations."""
        with self.lock:
            for animation in self.animations:
                animation.is_playing = False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get animation statistics.
        
        Returns:
            Statistics dictionary
        """
        with self.lock:
            return self.stats.copy()
