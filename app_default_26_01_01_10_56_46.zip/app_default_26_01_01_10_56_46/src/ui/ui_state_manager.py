import threading
from typing import Any, Dict, List, Optional, Callable
from dataclasses import dataclass, field
import time


@dataclass
class StateChange:
    """Record of a state change."""
    key: str
    old_value: Any
    new_value: Any
    timestamp: float = field(default_factory=time.time)


class UIStateManager:
    """Reactive UI state management system."""
    
    def __init__(self, max_undo_levels: int = 10):
        """Initialize UI state manager.
        
        Args:
            max_undo_levels: Maximum undo history levels
        """
        self.state: Dict[str, Any] = {}
        self.observers: Dict[str, List[Callable]] = {}
        self.undo_stack: List[Dict[str, Any]] = []
        self.redo_stack: List[Dict[str, Any]] = []
        self.max_undo_levels = max_undo_levels
        self.lock = threading.RLock()
        self.change_history: List[StateChange] = []
        self.batch_mode = False
        self.batch_changes: List[StateChange] = []
    
    def set_state(self, key: str, value: Any, notify: bool = True):
        """Set state value.
        
        Args:
            key: State key
            value: New value
            notify: Whether to notify observers
        """
        with self.lock:
            old_value = self.state.get(key)
            
            if old_value != value:
                # Save for undo
                if not self.batch_mode:
                    self.undo_stack.append(self.state.copy())
                    if len(self.undo_stack) > self.max_undo_levels:
                        self.undo_stack.pop(0)
                    self.redo_stack.clear()
                
                # Update state
                self.state[key] = value
                
                # Record change
                change = StateChange(key=key, old_value=old_value, new_value=value)
                
                if self.batch_mode:
                    self.batch_changes.append(change)
                else:
                    self.change_history.append(change)
                
                # Notify observers
                if notify and not self.batch_mode:
                    self._notify_observers(key, value)
    
    def get_state(self, key: str, default: Any = None) -> Any:
        """Get state value.
        
        Args:
            key: State key
            default: Default value if key not found
            
        Returns:
            State value or default
        """
        with self.lock:
            return self.state.get(key, default)
    
    def get_all_state(self) -> Dict[str, Any]:
        """Get all state.
        
        Returns:
            Copy of entire state dictionary
        """
        with self.lock:
            return self.state.copy()
    
    def observe(self, key: str, callback: Callable):
        """Observe state changes for a key.
        
        Args:
            key: State key to observe
            callback: Callback function to call on change
        """
        with self.lock:
            if key not in self.observers:
                self.observers[key] = []
            self.observers[key].append(callback)
    
    def unobserve(self, key: str, callback: Callable) -> bool:
        """Unobserve state changes.
        
        Args:
            key: State key
            callback: Callback to remove
            
        Returns:
            True if callback was removed
        """
        with self.lock:
            if key in self.observers:
                try:
                    self.observers[key].remove(callback)
                    return True
                except ValueError:
                    return False
        return False
    
    def _notify_observers(self, key: str, value: Any):
        """Notify observers of state change.
        
        Args:
            key: State key
            value: New value
        """
        if key in self.observers:
            for callback in self.observers[key]:
                try:
                    callback(value)
                except Exception:
                    pass
    
    def batch_update(self, updates: Dict[str, Any]):
        """Perform batch state update.
        
        Args:
            updates: Dictionary of key-value updates
        """
        with self.lock:
            self.batch_mode = True
            self.batch_changes = []
            
            try:
                for key, value in updates.items():
                    self.set_state(key, value, notify=False)
            
            finally:
                self.batch_mode = False
                
                # Save undo checkpoint
                self.undo_stack.append(self.state.copy())
                if len(self.undo_stack) > self.max_undo_levels:
                    self.undo_stack.pop(0)
                self.redo_stack.clear()
                
                # Record changes
                self.change_history.extend(self.batch_changes)
                
                # Notify observers
                for key in updates.keys():
                    self._notify_observers(key, self.state[key])
    
    def undo(self) -> bool:
        """Undo last state change.
        
        Returns:
            True if undo was successful
        """
        with self.lock:
            if not self.undo_stack:
                return False
            
            self.redo_stack.append(self.state.copy())
            self.state = self.undo_stack.pop()
            
            for key in self.state.keys():
                self._notify_observers(key, self.state[key])
            
            return True
    
    def redo(self) -> bool:
        """Redo last undone state change.
        
        Returns:
            True if redo was successful
        """
        with self.lock:
            if not self.redo_stack:
                return False
            
            self.undo_stack.append(self.state.copy())
            self.state = self.redo_stack.pop()
            
            for key in self.state.keys():
                self._notify_observers(key, self.state[key])
            
            return True
    
    def clear_state(self):
        """Clear all state."""
        with self.lock:
            self.state.clear()
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.change_history.clear()
            self.observers.clear()
    
    def get_change_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get state change history.
        
        Args:
            limit: Maximum number of changes to return
            
        Returns:
            List of change records
        """
        with self.lock:
            history = self.change_history[-limit:]
            return [
                {
                    'key': c.key,
                    'old_value': str(c.old_value)[:50],
                    'new_value': str(c.new_value)[:50],
                    'timestamp': c.timestamp
                }
                for c in history
            ]
    
    def update(self):
        """Update state manager (called each frame)."""
        pass
