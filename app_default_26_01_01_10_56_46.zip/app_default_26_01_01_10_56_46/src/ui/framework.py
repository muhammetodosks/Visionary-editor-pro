import pygame
import threading
import time
from typing import Optional, Dict, Any, List
from enum import Enum
import logging

from animation_engine import AnimationEngine
from ui_state_manager import UIStateManager
from theme_manager import ThemeManager


logger = logging.getLogger(__name__)


class UIFramework:
    """Base UI framework for application interface."""
    
    def __init__(self, width: int = 1400, height: int = 900):
        """Initialize UI framework.
        
        Args:
            width: Window width
            height: Window height
        """
        self.width = width
        self.height = height
        self.display = None
        self.clock = None
        self.running = False
        self.event_dispatcher = None
        
        self.animation_engine = AnimationEngine()
        self.state_manager = UIStateManager()
        self.theme_manager = ThemeManager()
        
        self.components: Dict[str, Any] = {}
        self.lock = threading.RLock()
        self.frame_time = 0
        self.fps_clock = None
        
        pygame.init()
    
    def initialize(self, event_dispatcher):
        """Initialize UI framework.
        
        Args:
            event_dispatcher: Event dispatcher instance
        """
        try:
            self.event_dispatcher = event_dispatcher
            self.display = pygame.display.set_mode((self.width, self.height))
            pygame.display.set_caption("VISIONARY PRO ULTRA v2.0.0")
            self.clock = pygame.time.Clock()
            self.fps_clock = time.time()
            
            self._create_components()
            
            logger.info("UI Framework initialized")
            
        except Exception as e:
            logger.error(f"Error initializing UI Framework: {e}")
            raise
    
    def _create_components(self):
        """Create UI components."""
        with self.lock:
            # Main window component
            from window import Window
            self.components['main_window'] = Window(
                x=0, y=0,
                width=self.width, height=self.height,
                event_dispatcher=self.event_dispatcher,
                theme_manager=self.theme_manager,
                animation_engine=self.animation_engine
            )
    
    def set_theme(self, theme_name: str):
        """Set application theme.
        
        Args:
            theme_name: Name of theme (cyberpunk, arctic, sunset)
        """
        try:
            self.theme_manager.set_theme(theme_name)
            logger.info(f"Theme set to: {theme_name}")
        except Exception as e:
            logger.error(f"Error setting theme: {e}")
    
    def run(self):
        """Run UI main loop."""
        self.running = True
        
        try:
            while self.running:
                self._handle_events()
                self._update()
                self._render()
        
        except Exception as e:
            logger.error(f"Error in UI loop: {e}")
        
        finally:
            self.shutdown()
    
    def _handle_events(self):
        """Handle pygame events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                self.event_dispatcher.emit("app:shutdown")
            
            elif event.type == pygame.KEYDOWN:
                self._handle_keydown(event)
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self._handle_mousedown(event)
            
            elif event.type == pygame.MOUSEMOTION:
                self._handle_mousemotion(event)
    
    def _handle_keydown(self, event):
        """Handle key down event."""
        if event.key == pygame.K_ESCAPE:
            self.running = False
            self.event_dispatcher.emit("app:shutdown")
        
        elif event.key == pygame.K_SPACE:
            if self.state_manager.get_state('paused'):
                self.event_dispatcher.emit("app:resume")
                self.state_manager.set_state('paused', False)
            else:
                self.event_dispatcher.emit("app:pause")
                self.state_manager.set_state('paused', True)
        
        elif event.key == pygame.K_t:
            current_theme = self.theme_manager.current_theme
            themes = list(self.theme_manager.themes.keys())
            next_theme = themes[(themes.index(current_theme) + 1) % len(themes)]
            self.event_dispatcher.emit("app:theme_change", {'theme': next_theme})
    
    def _handle_mousedown(self, event):
        """Handle mouse down event."""
        with self.lock:
            for component_name, component in self.components.items():
                if hasattr(component, 'on_mouse_click'):
                    component.on_mouse_click(event.pos, event.button)
    
    def _handle_mousemotion(self, event):
        """Handle mouse motion event."""
        with self.lock:
            for component_name, component in self.components.items():
                if hasattr(component, 'on_mouse_move'):
                    component.on_mouse_move(event.pos)
    
    def _update(self):
        """Update UI state."""
        current_time = time.time()
        dt = current_time - self.fps_clock
        self.fps_clock = current_time
        
        self.animation_engine.update(dt)
        self.state_manager.update()
        
        with self.lock:
            for component in self.components.values():
                if hasattr(component, 'update'):
                    component.update(dt)
    
    def _render(self):
        """Render UI."""
        try:
            # Clear display
            theme = self.theme_manager.get_current_theme()
            bg_color = theme.get('background', (20, 20, 30))
            self.display.fill(bg_color)
            
            with self.lock:
                for component in self.components.values():
                    if hasattr(component, 'render'):
                        component.render(self.display)
            
            pygame.display.flip()
            self.clock.tick(120)
            
        except Exception as e:
            logger.error(f"Error rendering: {e}")
    
    def shutdown(self):
        """Shutdown UI framework."""
        try:
            self.running = False
            pygame.quit()
            logger.info("UI Framework shutdown")
        except Exception as e:
            logger.error(f"Error shutting down UI: {e}")
