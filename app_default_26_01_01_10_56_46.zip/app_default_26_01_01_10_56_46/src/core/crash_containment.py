import threading
import traceback
import logging
from typing import Optional, List, Dict, Any
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import functools


logger = logging.getLogger(__name__)


class ErrorSeverity(Enum):
    """Error severity levels."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class CrashRecord:
    """Record of a crash or error."""
    timestamp: datetime = field(default_factory=datetime.now)
    severity: ErrorSeverity = ErrorSeverity.ERROR
    error_type: str = ""
    message: str = ""
    context: str = ""
    traceback_str: str = ""
    thread_name: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Dictionary representation
        """
        return {
            'timestamp': self.timestamp.isoformat(),
            'severity': self.severity.value,
            'error_type': self.error_type,
            'message': self.message,
            'context': self.context,
            'thread_name': self.thread_name,
            'traceback': self.traceback_str[:500]
        }


class CrashContainment:
    """Crash containment and error isolation system."""
    
    def __init__(self, max_history: int = 50, log_file: Optional[str] = None):
        """Initialize crash containment system.
        
        Args:
            max_history: Maximum number of crash records to keep
            log_file: Optional file to log crashes to
        """
        self.max_history = max_history
        self.log_file = log_file
        self.crash_history: List[CrashRecord] = []
        self.lock = threading.RLock()
        self.error_counts: Dict[str, int] = {}
        self.current_error_context: Optional[str] = None
    
    def capture_error(self, error: Exception, severity: ErrorSeverity = ErrorSeverity.ERROR,
                     context: str = "") -> CrashRecord:
        """Capture and contain an error.
        
        Args:
            error: Exception that occurred
            severity: Severity level of the error
            context: Additional context information
            
        Returns:
            CrashRecord containing error information
        """
        try:
            with self.lock:
                record = CrashRecord(
                    severity=severity,
                    error_type=type(error).__name__,
                    message=str(error),
                    context=context,
                    traceback_str=traceback.format_exc(),
                    thread_name=threading.current_thread().name
                )
                
                self.crash_history.append(record)
                if len(self.crash_history) > self.max_history:
                    self.crash_history.pop(0)
                
                # Update error counts
                error_key = f"{record.error_type}:{context}"
                self.error_counts[error_key] = self.error_counts.get(error_key, 0) + 1
                
                self._log_error(record)
                
                if severity == ErrorSeverity.CRITICAL:
                    logger.critical(f"CRITICAL ERROR: {record.message}\n{record.traceback_str}")
                elif severity == ErrorSeverity.ERROR:
                    logger.error(f"ERROR: {record.message}")
                elif severity == ErrorSeverity.WARNING:
                    logger.warning(f"WARNING: {record.message}")
                else:
                    logger.info(f"INFO: {record.message}")
                
                return record
        
        except Exception as e:
            logger.exception(f"Error in crash containment: {e}")
            raise
    
    def _log_error(self, record: CrashRecord):
        """Log error to file if configured.
        
        Args:
            record: Crash record to log
        """
        if self.log_file:
            try:
                with open(self.log_file, 'a') as f:
                    f.write(f"\n{record.timestamp.isoformat()} - {record.severity.value.upper()}\n")
                    f.write(f"Type: {record.error_type}\n")
                    f.write(f"Message: {record.message}\n")
                    f.write(f"Context: {record.context}\n")
                    f.write(f"Thread: {record.thread_name}\n")
                    f.write(f"Traceback:\n{record.traceback_str}\n")
                    f.write("-" * 80 + "\n")
            except Exception as e:
                logger.error(f"Error writing to log file: {e}")
    
    def safe_execute(self, func, *args, severity: ErrorSeverity = ErrorSeverity.ERROR,
                    context: str = "", fallback_return=None, **kwargs):
        """Safely execute a function with error containment.
        
        Args:
            func: Function to execute
            args: Positional arguments
            severity: Severity level for errors
            context: Context information
            fallback_return: Return value if error occurs
            kwargs: Keyword arguments
            
        Returns:
            Function result or fallback_return if error occurs
        """
        try:
            return func(*args, **kwargs)
        except Exception as e:
            self.capture_error(e, severity, context or func.__name__)
            return fallback_return
    
    def safe_decorator(self, severity: ErrorSeverity = ErrorSeverity.ERROR):
        """Decorator for safe function execution.
        
        Args:
            severity: Severity level for errors
            
        Returns:
            Decorator function
        """
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    self.capture_error(e, severity, func.__name__)
                    return None
            return wrapper
        return decorator
    
    def get_history(self, limit: int = 50, severity_filter: Optional[ErrorSeverity] = None) -> List[Dict[str, Any]]:
        """Get crash history.
        
        Args:
            limit: Maximum number of records to return
            severity_filter: Filter by severity level (optional)
            
        Returns:
            List of crash records
        """
        with self.lock:
            history = self.crash_history[-limit:]
            
            if severity_filter:
                history = [r for r in history if r.severity == severity_filter]
            
            return [r.to_dict() for r in history]
    
    def get_error_summary(self) -> Dict[str, Any]:
        """Get summary of errors.
        
        Returns:
            Summary dictionary
        """
        with self.lock:
            total = len(self.crash_history)
            by_severity = {}
            for record in self.crash_history:
                severity = record.severity.value
                by_severity[severity] = by_severity.get(severity, 0) + 1
            
            return {
                'total_errors': total,
                'by_severity': by_severity,
                'top_errors': sorted(
                    self.error_counts.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:5]
            }
    
    def print_history(self, limit: int = 10):
        """Print crash history to console.
        
        Args:
            limit: Maximum number of records to print
        """
        with self.lock:
            print("\n" + "=" * 80)
            print("CRASH CONTAINMENT HISTORY")
            print("=" * 80)
            
            for record in self.crash_history[-limit:]:
                print(f"\nTime: {record.timestamp}")
                print(f"Severity: {record.severity.value.upper()}")
                print(f"Type: {record.error_type}")
                print(f"Message: {record.message}")
                print(f"Context: {record.context}")
                print(f"Thread: {record.thread_name}")
                print("-" * 80)
            
            summary = self.get_error_summary()
            print(f"\nTotal Errors: {summary['total_errors']}")
            print(f"By Severity: {summary['by_severity']}")
            print("=" * 80 + "\n")
    
    def clear_history(self):
        """Clear crash history."""
        with self.lock:
            self.crash_history.clear()
            self.error_counts.clear()
            logger.info("Crash history cleared")
