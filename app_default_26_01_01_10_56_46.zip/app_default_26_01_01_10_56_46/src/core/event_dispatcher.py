import threading
import queue
import time
from typing import Callable, Dict, List, Optional, Any
from enum import Enum
from dataclasses import dataclass
import logging


logger = logging.getLogger(__name__)


class EventPriority(Enum):
    """Event priority levels."""
    LOW = 3
    NORMAL = 2
    HIGH = 1
    CRITICAL = 0


@dataclass
class Event:
    """Internal event representation."""
    name: str
    data: Optional[Any] = None
    priority: EventPriority = EventPriority.NORMAL
    callback: Optional[Callable] = None
    timestamp: float = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
    
    def __lt__(self, other):
        """For priority queue comparison."""
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        return self.timestamp < other.timestamp


class EventDispatcher:
    """Thread-safe event dispatcher system."""
    
    def __init__(self, max_queue_size: int = 1000, max_history: int = 100):
        """Initialize event dispatcher.
        
        Args:
            max_queue_size: Maximum size of event queue
            max_history: Maximum event history to keep
        """
        self.max_queue_size = max_queue_size
        self.max_history = max_history
        self.event_queue = queue.PriorityQueue(maxsize=max_queue_size)
        self.listeners: Dict[str, List[Callable]] = {}
        self.event_history: List[Event] = []
        self.lock = threading.RLock()
        self.processing_thread = None
        self.processing = False
        self.stats = {
            'total_events': 0,
            'processed_events': 0,
            'dropped_events': 0,
            'listener_count': 0
        }
    
    def on(self, event_name: str, callback: Callable, priority: EventPriority = EventPriority.NORMAL):
        """Register event listener.
        
        Args:
            event_name: Name of the event
            callback: Callback function to execute
            priority: Priority level for the listener
        """
        with self.lock:
            if event_name not in self.listeners:
                self.listeners[event_name] = []
            
            listener_info = (callback, priority)
            self.listeners[event_name].append(listener_info)
            self.stats['listener_count'] += 1
            logger.debug(f"Listener registered for event: {event_name}")
    
    def off(self, event_name: str, callback: Callable) -> bool:
        """Unregister event listener.
        
        Args:
            event_name: Name of the event
            callback: Callback function to remove
            
        Returns:
            True if listener was removed, False otherwise
        """
        with self.lock:
            if event_name not in self.listeners:
                return False
            
            for i, (listener_cb, _) in enumerate(self.listeners[event_name]):
                if listener_cb == callback:
                    self.listeners[event_name].pop(i)
                    self.stats['listener_count'] -= 1
                    logger.debug(f"Listener removed for event: {event_name}")
                    return True
        
        return False
    
    def emit(self, event_name: str, data: Optional[Any] = None, 
             priority: EventPriority = EventPriority.NORMAL, async_emit: bool = False):
        """Emit an event.
        
        Args:
            event_name: Name of the event
            data: Data to pass with event
            priority: Priority level of the event
            async_emit: If True, emit asynchronously
        """
        event = Event(name=event_name, data=data, priority=priority)
        
        try:
            if async_emit:
                self.event_queue.put_nowait((priority.value, id(event), event))
            else:
                self._emit_immediate(event)
            
            self.stats['total_events'] += 1
            self._record_history(event)
            
        except queue.Full:
            self.stats['dropped_events'] += 1
            logger.warning(f"Event queue full, dropped event: {event_name}")
    
    def _emit_immediate(self, event: Event):
        """Emit event immediately to all listeners.
        
        Args:
            event: Event to emit
        """
        with self.lock:
            if event.name not in self.listeners:
                return
            
            listeners = self.listeners[event.name].copy()
        
        for callback, _ in listeners:
            try:
                callback(event.data)
            except Exception as e:
                logger.error(f"Error in event listener for {event.name}: {e}")
        
        self.stats['processed_events'] += 1
    
    def start_processing(self):
        """Start async event processing thread."""
        if self.processing:
            return
        
        self.processing = True
        self.processing_thread = threading.Thread(
            target=self._process_queue,
            daemon=True,
            name="EventProcessor"
        )
        self.processing_thread.start()
        logger.info("Event processing started")
    
    def stop_processing(self):
        """Stop async event processing."""
        self.processing = False
        if self.processing_thread:
            self.processing_thread.join(timeout=2)
        logger.info("Event processing stopped")
    
    def _process_queue(self):
        """Process events from queue continuously."""
        while self.processing:
            try:
                _, _, event = self.event_queue.get(timeout=0.5)
                self._emit_immediate(event)
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error processing event: {e}")
    
    def _record_history(self, event: Event):
        """Record event in history.
        
        Args:
            event: Event to record
        """
        with self.lock:
            self.event_history.append(event)
            if len(self.event_history) > self.max_history:
                self.event_history.pop(0)
    
    def get_history(self, event_name: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Get event history.
        
        Args:
            event_name: Filter by event name (optional)
            limit: Maximum number of events to return
            
        Returns:
            List of event records
        """
        with self.lock:
            history = self.event_history[-limit:]
            
            if event_name:
                history = [e for e in history if e.name == event_name]
            
            return [
                {
                    'name': e.name,
                    'priority': e.priority.name,
                    'timestamp': e.timestamp,
                    'data': str(e.data)[:100]
                }
                for e in history
            ]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get dispatcher statistics.
        
        Returns:
            Statistics dictionary
        """
        with self.lock:
            return self.stats.copy()
    
    def clear_all(self):
        """Clear all listeners and history."""
        with self.lock:
            self.listeners.clear()
            self.event_history.clear()
            self.stats['listener_count'] = 0
            logger.info("Event dispatcher cleared")
