import threading
import time
import os
from typing import Optional, Dict, Any
from enum import Enum
import logging

from event_dispatcher import EventDispatcher, EventPriority
from performance_governor import PerformanceGovernor, PerformanceState
from crash_containment import CrashContainment, ErrorSeverity


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AppState(Enum):
    """Application state enumeration."""
    INITIALIZING = "initializing"
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    SHUTDOWN = "shutdown"


class AppController:
    """Master application controller orchestrating all systems."""
    
    def __init__(self, ui_framework, crash_containment: CrashContainment):
        """Initialize application controller.
        
        Args:
            ui_framework: UI framework instance
            crash_containment: Crash containment system
        """
        self.ui_framework = ui_framework
        self.crash_containment = crash_containment
        self.event_dispatcher = EventDispatcher()
        self.performance_governor = PerformanceGovernor()
        
        self.state = AppState.INITIALIZING
        self.running = False
        self.lock = threading.RLock()
        self.engines = {}
        self.state_data: Dict[str, Any] = {}
        
        self._setup_event_handlers()
    
    def _setup_event_handlers(self):
        """Setup event handlers for application events."""
        self.event_dispatcher.on("app:shutdown", self._handle_shutdown)
        self.event_dispatcher.on("app:pause", self._handle_pause)
        self.event_dispatcher.on("app:resume", self._handle_resume)
        self.event_dispatcher.on("app:theme_change", self._handle_theme_change)
        self.event_dispatcher.on("performance:state_change", self._handle_performance_state)
    
    def initialize(self):
        """Initialize all application systems."""
        try:
            logger.info("Initializing Application Controller...")
            
            self._initialize_engines()
            self._initialize_ui()
            self._start_monitoring()
            
            self.state = AppState.IDLE
            logger.info("Application initialized successfully")
            
        except Exception as e:
            self.crash_containment.capture_error(
                error=e,
                severity=ErrorSeverity.CRITICAL,
                context="AppController.initialize"
            )
            raise
    
    def _initialize_engines(self):
        """Initialize all background engines."""
        try:
            if os.environ.get('ENABLE_HARDWARE_MONITORING', 'True') == 'True':
                from engines.hardware_monitor_engine import HardwareMonitorEngine
                self.engines['hardware'] = HardwareMonitorEngine(self.event_dispatcher)
                self.engines['hardware'].start()
            
            if os.environ.get('ENABLE_VISION_PROCESSING', 'True') == 'True':
                from engines.vision_engine import VisionEngine
                self.engines['vision'] = VisionEngine(self.event_dispatcher)
                self.engines['vision'].start()
            
            if os.environ.get('ENABLE_AI_INFERENCE', 'False') == 'True':
                from engines.ai_engine import AIEngine
                self.engines['ai'] = AIEngine(self.event_dispatcher)
                self.engines['ai'].start()
            
            logger.info(f"Initialized {len(self.engines)} engines")
            
        except Exception as e:
            self.crash_containment.capture_error(
                error=e,
                severity=ErrorSeverity.WARNING,
                context="AppController._initialize_engines"
            )
    
    def _initialize_ui(self):
        """Initialize UI framework."""
        try:
            theme = os.environ.get('APP_THEME', 'cyberpunk')
            self.ui_framework.set_theme(theme)
            self.ui_framework.initialize(self.event_dispatcher)
            logger.info("UI Framework initialized")
            
        except Exception as e:
            self.crash_containment.capture_error(
                error=e,
                severity=ErrorSeverity.CRITICAL,
                context="AppController._initialize_ui"
            )
            raise
    
    def _start_monitoring(self):
        """Start performance monitoring thread."""
        monitor_thread = threading.Thread(
            target=self._monitor_performance,
            daemon=True,
            name="PerformanceMonitor"
        )
        monitor_thread.start()
    
    def _monitor_performance(self):
        """Monitor performance metrics continuously."""
        while self.running:
            try:
                metrics = self.performance_governor.get_metrics()
                self.state_data['performance'] = metrics
                
                if metrics['state'] != PerformanceState.NORMAL:
                    self.event_dispatcher.emit(
                        "performance:metrics_updated",
                        metrics,
                        priority=EventPriority.HIGH
                    )
                
                time.sleep(1)
                
            except Exception as e:
                self.crash_containment.capture_error(
                    error=e,
                    severity=ErrorSeverity.WARNING,
                    context="AppController._monitor_performance"
                )
    
    def run(self):
        """Run the application main loop."""
        try:
            with self.lock:
                self.running = True
                self.state = AppState.RUNNING
            
            logger.info("Starting application main loop")
            self.ui_framework.run()
            
        except Exception as e:
            self.crash_containment.capture_error(
                error=e,
                severity=ErrorSeverity.CRITICAL,
                context="AppController.run"
            )
            raise
        
        finally:
            self.shutdown()
    
    def pause(self):
        """Pause the application."""
        with self.lock:
            if self.state == AppState.RUNNING:
                self.state = AppState.PAUSED
                self.event_dispatcher.emit("app:paused", priority=EventPriority.HIGH)
                logger.info("Application paused")
    
    def resume(self):
        """Resume the application."""
        with self.lock:
            if self.state == AppState.PAUSED:
                self.state = AppState.RUNNING
                self.event_dispatcher.emit("app:resumed", priority=EventPriority.HIGH)
                logger.info("Application resumed")
    
    def shutdown(self):
        """Shutdown the application gracefully."""
        try:
            with self.lock:
                if self.state == AppState.SHUTDOWN:
                    return
                
                self.state = AppState.SHUTDOWN
                self.running = False
            
            logger.info("Shutting down engines...")
            for engine_name, engine in self.engines.items():
                try:
                    if hasattr(engine, 'stop'):
                        engine.stop()
                    logger.info(f"Engine '{engine_name}' stopped")
                except Exception as e:
                    self.crash_containment.capture_error(
                        error=e,
                        severity=ErrorSeverity.WARNING,
                        context=f"AppController.shutdown - {engine_name}"
                    )
            
            self.ui_framework.shutdown()
            logger.info("Application shutdown complete")
            
        except Exception as e:
            self.crash_containment.capture_error(
                error=e,
                severity=ErrorSeverity.CRITICAL,
                context="AppController.shutdown"
            )
    
    def _handle_shutdown(self, *args, **kwargs):
        """Handle shutdown event."""
        self.shutdown()
    
    def _handle_pause(self, *args, **kwargs):
        """Handle pause event."""
        self.pause()
    
    def _handle_resume(self, *args, **kwargs):
        """Handle resume event."""
        self.resume()
    
    def _handle_theme_change(self, data=None, *args, **kwargs):
        """Handle theme change event."""
        if data and 'theme' in data:
            try:
                self.ui_framework.set_theme(data['theme'])
                logger.info(f"Theme changed to {data['theme']}")
            except Exception as e:
                self.crash_containment.capture_error(
                    error=e,
                    severity=ErrorSeverity.WARNING,
                    context="AppController._handle_theme_change"
                )
    
    def _handle_performance_state(self, data=None, *args, **kwargs):
        """Handle performance state change."""
        if data:
            logger.debug(f"Performance state: {data}")
    
    def get_state(self) -> Dict[str, Any]:
        """Get current application state.
        
        Returns:
            Dictionary containing state data
        """
        with self.lock:
            return {
                'state': self.state.value,
                'running': self.running,
                'engines': list(self.engines.keys()),
                'data': self.state_data.copy()
            }
