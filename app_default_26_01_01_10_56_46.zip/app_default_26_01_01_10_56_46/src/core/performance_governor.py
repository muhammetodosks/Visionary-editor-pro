import psutil
import threading
import time
from enum import Enum
from typing import Dict, Any
from dataclasses import dataclass
import logging


logger = logging.getLogger(__name__)


class PerformanceState(Enum):
    """Performance state levels."""
    IDLE = "idle"
    NORMAL = "normal"
    HIGH_LOAD = "high_load"
    CRITICAL = "critical"


@dataclass
class PerformanceMetrics:
    """Performance metrics data."""
    cpu_percent: float
    memory_percent: float
    gpu_memory_used: float
    current_fps: int
    target_fps: int
    state: PerformanceState
    thermal_throttling: bool


class PerformanceGovernor:
    """Dynamic performance governor with adaptive FPS scaling."""
    
    def __init__(self, min_fps: int = 30, max_fps: int = 120, 
                 update_interval: float = 0.5):
        """Initialize performance governor.
        
        Args:
            min_fps: Minimum FPS to maintain
            max_fps: Maximum FPS allowed
            update_interval: Interval for metrics update
        """
        self.min_fps = min_fps
        self.max_fps = max_fps
        self.update_interval = update_interval
        self.current_fps = max_fps
        self.target_fps = max_fps
        self.lock = threading.RLock()
        
        self.metrics = {
            'cpu_percent': 0.0,
            'memory_percent': 0.0,
            'gpu_memory_used': 0.0,
            'processes_count': 0,
            'disk_io_reads': 0,
            'disk_io_writes': 0
        }
        
        self.state = PerformanceState.NORMAL
        self.thermal_throttling = False
        self.last_update = time.time()
        self.frame_times = []
        self.max_frame_history = 60
        
        self._update_metrics()
    
    def update(self, frame_time: float = None):
        """Update performance governor with frame time.
        
        Args:
            frame_time: Time taken for last frame in seconds
        """
        if frame_time:
            with self.lock:
                self.frame_times.append(frame_time)
                if len(self.frame_times) > self.max_frame_history:
                    self.frame_times.pop(0)
                
                if len(self.frame_times) > 0:
                    avg_frame_time = sum(self.frame_times) / len(self.frame_times)
                    self.current_fps = max(1, int(1.0 / avg_frame_time)) if avg_frame_time > 0 else 0
        
        # Update metrics periodically
        now = time.time()
        if now - self.last_update >= self.update_interval:
            self._update_metrics()
            self.last_update = now
            self._adjust_performance()
    
    def _update_metrics(self):
        """Update performance metrics."""
        try:
            with self.lock:
                self.metrics['cpu_percent'] = psutil.cpu_percent(interval=0.1)
                self.metrics['memory_percent'] = psutil.virtual_memory().percent
                self.metrics['processes_count'] = len(psutil.pids())
                
                disk_io = psutil.disk_io_counters()
                if disk_io:
                    self.metrics['disk_io_reads'] = disk_io.read_count
                    self.metrics['disk_io_writes'] = disk_io.write_count
                
                # Check thermal throttling
                temps = psutil.sensors_temperatures()
                if temps:
                    max_temp = 0
                    for temp_type, temp_list in temps.items():
                        for temp in temp_list:
                            max_temp = max(max_temp, temp.current)
                    self.thermal_throttling = max_temp > 85
                
                # GPU memory estimation (simplified)
                self.metrics['gpu_memory_used'] = 0.0
                
        except Exception as e:
            logger.warning(f"Error updating metrics: {e}")
    
    def _adjust_performance(self):
        """Adjust performance based on system load."""
        with self.lock:
            cpu = self.metrics['cpu_percent']
            memory = self.metrics['memory_percent']
            
            # Determine performance state
            if cpu > 90 or memory > 90 or self.thermal_throttling:
                new_state = PerformanceState.CRITICAL
                self.target_fps = self.min_fps
            elif cpu > 75 or memory > 75:
                new_state = PerformanceState.HIGH_LOAD
                self.target_fps = int(self.max_fps * 0.6)
            elif cpu > 50 or memory > 60:
                new_state = PerformanceState.NORMAL
                self.target_fps = int(self.max_fps * 0.8)
            else:
                new_state = PerformanceState.IDLE
                self.target_fps = self.max_fps
            
            if new_state != self.state:
                self.state = new_state
                logger.info(f"Performance state changed to: {self.state.value}")
    
    def get_fps_cap(self) -> int:
        """Get current FPS cap.
        
        Returns:
            FPS cap value
        """
        with self.lock:
            return max(self.min_fps, min(self.target_fps, self.max_fps))
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics.
        
        Returns:
            Dictionary containing performance metrics
        """
        with self.lock:
            return {
                'cpu_percent': round(self.metrics['cpu_percent'], 2),
                'memory_percent': round(self.metrics['memory_percent'], 2),
                'gpu_memory_used': round(self.metrics['gpu_memory_used'], 2),
                'current_fps': self.current_fps,
                'target_fps': self.target_fps,
                'state': self.state.value,
                'thermal_throttling': self.thermal_throttling,
                'processes_count': self.metrics['processes_count']
            }
    
    def should_skip_frame(self) -> bool:
        """Check if current frame should be skipped.
        
        Returns:
            True if frame should be skipped
        """
        if self.state == PerformanceState.CRITICAL:
            return True
        if self.state == PerformanceState.HIGH_LOAD:
            return self.current_fps % 3 == 0
        return False
    
    def get_throttle_factor(self) -> float:
        """Get performance throttle factor (0.0 to 1.0).
        
        Returns:
            Throttle factor
        """
        with self.lock:
            if self.state == PerformanceState.IDLE:
                return 1.0
            elif self.state == PerformanceState.NORMAL:
                return 0.9
            elif self.state == PerformanceState.HIGH_LOAD:
                return 0.6
            else:
                return 0.3
