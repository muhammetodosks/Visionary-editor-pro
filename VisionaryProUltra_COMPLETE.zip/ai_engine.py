"""
AI ENGINE - Face and eye detection with efficient resource management
"""
import cv2
import numpy as np
import threading
import queue
import logging

logger = logging.getLogger("AIEngine")

class AIEngine:
    """Yüz ve göz algılama motoru."""
    
    def __init__(self):
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        self.eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_eye.xml'
        )
        
        self.enabled = False
        self.detect_eyes = False
        self.detection_queue = queue.Queue(maxsize=1)
        self.running = False
        self.lock = threading.RLock()
        
        logger.info("AI Engine başlatıldı")
    
    def enable(self, state: bool):
        """AI'ı aç/kapat."""
        with self.lock:
            self.enabled = state
    
    def set_eye_detection(self, state: bool):
        """Göz algılamasını aç/kapat."""
        with self.lock:
            self.detect_eyes = state
    
    def detect(self, frame: np.ndarray) -> dict:
        """Yüz ve göz algılaması yap."""
        with self.lock:
            if not self.enabled:
                return {"faces": [], "eyes": []}
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
        
        result = {
            "faces": [],
            "eyes": []
        }
        
        for (x, y, w, h) in faces:
            result["faces"].append((x, y, w, h))
            
            if self.detect_eyes:
                roi_gray = gray[y:y+h, x:x+w]
                eyes = self.eye_cascade.detectMultiScale(roi_gray)
                for (ex, ey, ew, eh) in eyes:
                    result["eyes"].append((x+ex, y+ey, ew, eh))
        
        return result
    
    def process_loop(self, frame_source, shutdown_event):
        """Asenkron algılama döngüsü."""
        self.running = True
        while not shutdown_event.is_set() and self.running:
            frame = frame_source()
            if frame is not None:
                detection = self.detect(frame)
                try:
                    self.detection_queue.put_nowait(detection)
                except queue.Full:
                    pass
        self.running = False
    
    def get_detections(self) -> dict:
        """Son algılamalar."""
        try:
            return self.detection_queue.get_nowait()
        except queue.Empty:
            return {"faces": [], "eyes": []}
