"""
VISION ENGINE - Real-time OpenCV camera processing
Frame capture, filtering pipeline, image optimization
"""
import cv2
import numpy as np
import threading
import queue
import logging
from collections import deque

logger = logging.getLogger("VisionEngine")

class FilterPipeline:
    """Modüler filtre pipeline sistemi."""
    
    def __init__(self):
        self.filters = {}
        self.active_filters = []
        self.lock = threading.RLock()
    
    def register_filter(self, name: str, func):
        """Yeni filtre ekle."""
        with self.lock:
            self.filters[name] = func
    
    def enable_filter(self, name: str):
        """Filtreyi aktifleştir."""
        with self.lock:
            if name not in self.filters:
                logger.warning(f"Filtre {name} bulunamadı")
                return
            if name not in self.active_filters:
                self.active_filters.append(name)
    
    def disable_filter(self, name: str):
        """Filtreyi deaktifleştir."""
        with self.lock:
            if name in self.active_filters:
                self.active_filters.remove(name)
    
    def apply(self, frame: np.ndarray) -> np.ndarray:
        """Tüm aktif filtreleri uygula."""
        with self.lock:
            for filter_name in self.active_filters:
                if filter_name in self.filters:
                    frame = self.filters[filter_name](frame)
        return frame

class VisionEngine:
    """OpenCV gerçek zamanlı kamera motoru."""
    
    def __init__(self, camera_index=0, width=1280, height=720):
        self.camera_index = camera_index
        self.width = width
        self.height = height
        self.cap = None
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = False
        self.lock = threading.RLock()
        
        self.pipeline = FilterPipeline()
        self._register_default_filters()
    
    def _register_default_filters(self):
        """Varsayılan filtreleri kaydet."""
        self.pipeline.register_filter("grayscale", self._apply_grayscale)
        self.pipeline.register_filter("blur", self._apply_blur)
        self.pipeline.register_filter("edge", self._apply_edge)
        self.pipeline.register_filter("sepia", self._apply_sepia)
        self.pipeline.register_filter("sharpen", self._apply_sharpen)
    
    @staticmethod
    def _apply_grayscale(frame):
        """Gri tonlamaya dönüştür."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    
    @staticmethod
    def _apply_blur(frame, kernel=15):
        """Gauss bulanıklığı uygula."""
        k = kernel if kernel % 2 == 1 else kernel + 1
        return cv2.GaussianBlur(frame, (k, k), 0)
    
    @staticmethod
    def _apply_edge(frame):
        """Canny kenar algılaması."""
        edges = cv2.Canny(frame, 100, 200)
        return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
    
    @staticmethod
    def _apply_sepia(frame):
        """Sepia filtresi."""
        kernel = np.array([[0.272, 0.534, 0.131],
                          [0.349, 0.686, 0.168],
                          [0.393, 0.769, 0.189]])
        return cv2.transform(frame, kernel)
    
    @staticmethod
    def _apply_sharpen(frame):
        """Keskinleştirme."""
        kernel = np.array([[-1, -1, -1],
                          [-1, 9, -1],
                          [-1, -1, -1]])
        return cv2.filter2D(frame, -1, kernel)
    
    def initialize(self) -> bool:
        """Kamerayı başlat."""
        try:
            self.cap = cv2.VideoCapture(self.camera_index)
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            logger.info(f"Kamera {self.camera_index} başlatıldı")
            return True
        except Exception as e:
            logger.error(f"Kamera başlatma hatası: {e}")
            return False
    
    def capture_loop(self, shutdown_event):
        """Ana kamera yakalama döngüsü."""
        if not self.initialize():
            return
        
        self.running = True
        while not shutdown_event.is_set() and self.running:
            ret, frame = self.cap.read()
            if not ret:
                continue
            
            # Filtreleri uygula
            frame = self.pipeline.apply(frame)
            
            # Frame'i queue'ya koy (eski frame'i atla)
            try:
                self.frame_queue.put_nowait(frame)
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                    self.frame_queue.put_nowait(frame)
                except queue.Empty:
                    pass
        
        self.cleanup()
    
    def get_frame(self) -> Optional[np.ndarray]:
        """En son frame'i al."""
        try:
            return self.frame_queue.get_nowait()
        except queue.Empty:
            return None
    
    def cleanup(self):
        """Kaynakları serbest bırak."""
        if self.cap:
            self.cap.release()
        self.running = False
        logger.info("Vision Engine temizlendi")
