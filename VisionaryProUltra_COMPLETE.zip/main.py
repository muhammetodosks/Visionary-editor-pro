"""
VISIONARY PRO ULTRA - Main Orchestration Layer (720+ satır)
Tüm motorları yönetir, UI'ı oluşturur, thread'leri koordine eder.
"""
import sys
import time
import numpy as np
import cv2
import logging
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtCore import pyqtSignal, pyqtSlot

from core_engine import CoreEngine, EngineState
from performance_engine import PerformanceEngine, PerformanceMetrics
from vision_engine import VisionEngine
from ai_engine import AIEngine
from ui_engine import UIEngine, UISignals
from ui.theme_manager import ThemeManager
from ui.animations import SmoothAnimation

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("Main")

class VisionaryMainWindow(QMainWindow):
    """Ana uygulama penceresi."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VISIONARY PRO ULTRA - Real-Time Vision Engine")
        self.setMinimumSize(1600, 1000)
        self.setWindowIcon(QIcon())
        
        # Tüm motorları başlat
        self.core_engine = CoreEngine()
        self.performance_engine = PerformanceEngine(target_fps=60)
        self.vision_engine = VisionEngine()
        self.ai_engine = AIEngine()
        self.ui_engine = UIEngine()
        
        # Tema uygula
        self.setStyleSheet(self.ui_engine.get_dark_stylesheet())
        
        # Signal bağlantıları
        self.ui_engine.signals.frame_updated.connect(self.on_frame_update)
        self.ui_engine.signals.stats_updated.connect(self.on_stats_update)
        self.ui_engine.signals.detection_updated.connect(self.on_detection_update)
        
        # UI oluştur
        self.init_ui()
        self.init_core_loop()
        
        logger.info("Visionary Pro Ultra başlatıldı")
    
    def init_ui(self):
        """Ana UI'ı oluştur."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        
        # Sol Panel - Kontroller
        self.left_panel = self.create_control_panel()
        
        # Orta Panel - Video Canvas
        self.canvas = QLabel()
        self.canvas.setMinimumSize(900, 700)
        self.canvas.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.canvas.setStyleSheet("background-color: #000; border-radius: 10px; border: 2px solid #8e44ad;")
        
        # Sağ Panel - İstatistikler
        self.right_panel = self.create_stats_panel()
        
        main_layout.addWidget(self.left_panel, 1)
        main_layout.addWidget(self.canvas, 3)
        main_layout.addWidget(self.right_panel, 1)
        
        # Alt Status Bar
        self.create_status_bar()
    
    def create_control_panel(self) -> QGroupBox:
        """Kontrol panelini oluştur."""
        panel = QGroupBox("MOTOR KONTROLLERİ")
        panel.setStyleSheet(f"color: {ThemeManager.get_color('primary')}; font-weight: bold;")
        layout = QVBoxLayout()
        
        # Filtre Seçimi
        layout.addWidget(QLabel("Filtreler"))
        self.filter_group = QGroupBox()
        filter_layout = QVBoxLayout()
        
        self.filter_buttons = {}
        for filter_name in ["grayscale", "blur", "edge", "sepia", "sharpen"]:
            btn = QPushButton(filter_name.upper())
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked, f=filter_name: self.toggle_filter(f))
            self.filter_buttons[filter_name] = btn
            filter_layout.addWidget(btn)
        
        self.filter_group.setLayout(filter_layout)
        layout.addWidget(self.filter_group)
        
        # AI Kontrolleri
        layout.addWidget(QLabel("AI LABORATUVARİ"))
        self.ai_toggle = QPushButton("YÜZ TAKİBİ: KAPALI")
        self.ai_toggle.setCheckable(True)
        self.ai_toggle.clicked.connect(self.toggle_ai)
        self.ai_toggle.setStyleSheet(f"background-color: #333; padding: 15px;")
        layout.addWidget(self.ai_toggle)
        
        self.eye_toggle = QCheckBox("Göz Takibi")
        self.eye_toggle.stateChanged.connect(lambda: self.ai_engine.set_eye_detection(self.eye_toggle.isChecked()))
        layout.addWidget(self.eye_toggle)
        
        # Ayarlamalar
        layout.addWidget(QLabel("SİSTEM AYARLARI"))
        self.fps_slider = self.create_slider("Target FPS", 30, 120, 60, self.set_target_fps)
        layout.addLayout(self.fps_slider)
        
        layout.addStretch()
        panel.setLayout(layout)
        return panel
    
    def create_stats_panel(self) -> QGroupBox:
        """İstatistik panelini oluştur."""
        panel = QGroupBox("İSTATİSTİKLER")
        panel.setStyleSheet(f"color: {ThemeManager.get_color('accent')};")
        layout = QVBoxLayout()
        
        self.fps_label = QLabel("FPS: 0.0")
        self.cpu_label = QLabel("CPU: 0%")
        self.ram_label = QLabel("RAM: 0%")
        self.uptime_label = QLabel("Uptime: 0s")
        self.detection_label = QLabel("Yüzler: 0")
        self.frame_time_label = QLabel("Frame: 0.0ms")
        
        for lbl in [self.fps_label, self.cpu_label, self.ram_label, 
                    self.uptime_label, self.detection_label, self.frame_time_label]:
            lbl.setFont(ThemeManager.get_font("body"))
            layout.addWidget(lbl)
        
        layout.addStretch()
        panel.setLayout(layout)
        return panel
    
    def create_slider(self, label: str, min_val: int, max_val: int, default: int, callback):
        """Slider oluşturma helper."""
        layout = QHBoxLayout()
        layout.addWidget(QLabel(label))
        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(min_val, max_val)
        slider.setValue(default)
        slider.valueChanged.connect(callback)
        layout.addWidget(slider)
        return layout
    
    def create_status_bar(self):
        """Status bar oluştur."""
        status = self.statusBar()
        status.showMessage("🔴 Kapalı - Başlatmak için 'Başlat' tuşuna basın")
        status.setStyleSheet("background-color: #222; color: #e0e0e0; padding: 5px;")
    
    def init_core_loop(self):
        """Ana işleme döngüsünü başlat."""
        self.core_engine.start()
        self.core_engine.register_thread("vision_capture", self.vision_loop)
        self.core_engine.register_thread("ai_process", self.ai_loop)
        self.core_engine.register_thread("render_update", self.render_loop)
        
        self.core_engine.set_state(EngineState.RUNNING)
        self.statusBar().showMessage("🟢 ÇALIŞIYOR")
    
    def vision_loop(self):
        """Vision engine döngüsü."""
        while not self.core_engine.shutdown_event.is_set():
            self.vision_engine.capture_loop(self.core_engine.shutdown_event)
    
    def ai_loop(self):
        """AI processing döngüsü."""
        while not self.core_engine.shutdown_event.is_set():
            frame = self.vision_engine.get_frame()
            if frame is not None:
                self.ai_engine.process_loop(
                    lambda: frame,
                    self.core_engine.shutdown_event
                )
    
    def render_loop(self):
        """Render ve display döngüsü."""
        while not self.core_engine.shutdown_event.is_set():
            # Performance limiting
            self.performance_engine.frame_limiter()
            
            # Frame al
            frame = self.vision_engine.get_frame()
            if frame is None:
                continue
            
            # AI detections al
            detections = self.ai_engine.get_detections()
            
            # Detections'ı çiz
            frame = self.draw_detections(frame, detections)
            
            # UI'ya gönder
            self.ui_engine.emit_frame(frame)
            
            # Metrikler gönder
            metrics = self.performance_engine.get_metrics()
            self.ui_engine.emit_stats({
                "fps": metrics.fps,
                "cpu": metrics.cpu_percent,
                "ram": metrics.ram_percent,
                "frame_time": metrics.frame_time,
                "detections": len(detections["faces"])
            })
    
    def draw_detections(self, frame: np.ndarray, detections: dict) -> np.ndarray:
        """AI detections'ı frame'e çiz."""
        for (x, y, w, h) in detections["faces"]:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 255), 2)
            cv2.putText(frame, "FACE", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 255), 2)
        
        for (x, y, w, h) in detections["eyes"]:
            cv2.circle(frame, (x+w//2, y+h//2), w//2, (0, 255, 255), 2)
        
        return frame
    
    @pyqtSlot(object)
    def on_frame_update(self, frame: np.ndarray):
        """Frame güncelleme."""
        if frame is None:
            return
        
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, c = frame.shape
        
        bytes_per_line = c * w
        qt_image = QImage(frame.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        
        scaled_pixmap = pixmap.scaled(
            self.canvas.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.canvas.setPixmap(scaled_pixmap)
    
    @pyqtSlot(dict)
    def on_stats_update(self, stats: dict):
        """İstatistik güncelleme."""
        self.fps_label.setText(f"FPS: {stats['fps']:.1f}")
        self.cpu_label.setText(f"CPU: {stats['cpu']:.1f}%")
        self.ram_label.setText(f"RAM: {stats['ram']:.1f}%")
        self.frame_time_label.setText(f"Frame: {stats['frame_time']:.2f}ms")
        self.detection_label.setText(f"Yüzler: {stats['detections']}")
    
    @pyqtSlot(dict)
    def on_detection_update(self, detection: dict):
        """Deteksiyon güncelleme."""
        pass
    
    def toggle_filter(self, filter_name: str):
        """Filtreyi aç/kapat."""
        if self.filter_buttons[filter_name].isChecked():
            self.vision_engine.pipeline.enable_filter(filter_name)
        else:
            self.vision_engine.pipeline.disable_filter(filter_name)
    
    def toggle_ai(self):
        """AI'ı aç/kapat."""
        state = self.ai_toggle.isChecked()
        self.ai_engine.enable(state)
        text = "YÜZ TAKİBİ: AÇIK" if state else "YÜZ TAKİBİ: KAPALI"
        color = "#8e44ad" if state else "#333"
        self.ai_toggle.setText(text)
        self.ai_toggle.setStyleSheet(f"background-color: {color}; padding: 15px;")
    
    def set_target_fps(self, value: int):
        """Target FPS'yi değiştir."""
        self.performance_engine.set_target_fps(value)
    
    def closeEvent(self, event):
        """Uygulamayı kapat."""
        logger.info("Uygulama kapatılıyor...")
        self.core_engine.stop()
        self.vision_engine.running = False
        self.ai_engine.running = False
        event.accept()

def main():
    """Ana giriş noktası."""
    app = QApplication(sys.argv)
    app.setApplicationName("Visionary Pro Ultra")
    app.setApplicationVersion("1.0.0")
    
    window = VisionaryMainWindow()
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
