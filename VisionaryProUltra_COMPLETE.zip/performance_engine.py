"""
PERFORMANCE ENGINE - Real-time optimization
FPS limiter, CPU/RAM monitoring, frame skipping, buffer management
"""
import time
import threading
import psutil
import queue
from collections import deque
from dataclasses import dataclass
from typing import Optional

@dataclass
class PerformanceMetrics:
    fps: float
    frame_time: float
    cpu_percent: float
    ram_percent: float
    dropped_frames: int
    buffer_size: int

class PerformanceEngine:
    """Performans optimizasyonu ve monitoring."""
    
    def __init__(self, target_fps=60, max_ram_percent=80):
        self.target_fps = target_fps
        self.target_frame_time = 1.0 / target_fps
        self.max_ram_percent = max_ram_percent
        
        self.frame_times = deque(maxlen=60)
        self.lock = threading.RLock()
        self.last_frame_time = time.time()
        self.dropped_frames = 0
        self.buffer_queue = queue.Queue(maxsize=10)
        
        self.process = psutil.Process()
    
    def frame_limiter(self) -> float:
        """Frame limiter - target FPS'i koruyup fazla kareları atla."""
        current_time = time.time()
        elapsed = current_time - self.last_frame_time
        
        if elapsed < self.target_frame_time:
            sleep_time = self.target_frame_time - elapsed
            time.sleep(sleep_time)
            frame_time = self.target_frame_time
        else:
            frame_time = elapsed
            self.dropped_frames += 1
        
        self.last_frame_time = time.time()
        
        with self.lock:
            self.frame_times.append(frame_time)
        
        return frame_time
    
    def get_fps(self) -> float:
        """Ortalama FPS hesapla."""
        with self.lock:
            if not self.frame_times:
                return 0
            avg_frame_time = sum(self.frame_times) / len(self.frame_times)
            return 1.0 / avg_frame_time if avg_frame_time > 0 else 0
    
    def get_system_resources(self) -> tuple:
        """CPU ve RAM yüzdesini al."""
        cpu_percent = self.process.cpu_percent(interval=None)
        ram_info = self.process.memory_info()
        ram_percent = self.process.memory_percent()
        return cpu_percent, ram_percent
    
    def should_skip_frame(self) -> bool:
        """Frame'i atlamalı mıyız? (RAM basıncı varsa)"""
        _, ram_percent = self.get_system_resources()
        return ram_percent > self.max_ram_percent
    
    def cleanup_buffers(self):
        """Memory cache'i temizle."""
        while not self.buffer_queue.empty():
            try:
                self.buffer_queue.get_nowait()
            except queue.Empty:
                break
    
    def get_metrics(self) -> PerformanceMetrics:
        """Tüm performans metriklerini döndür."""
        cpu, ram = self.get_system_resources()
        
        with self.lock:
            avg_frame_time = (sum(self.frame_times) / len(self.frame_times)) if self.frame_times else 0
        
        return PerformanceMetrics(
            fps=self.get_fps(),
            frame_time=avg_frame_time * 1000,
            cpu_percent=cpu,
            ram_percent=ram,
            dropped_frames=self.dropped_frames,
            buffer_size=self.buffer_queue.qsize()
        )
    
    def set_target_fps(self, fps: int):
        """Hedef FPS'yi değiştir."""
        with self.lock:
            self.target_fps = fps
            self.target_frame_time = 1.0 / fps
