"""
THEME MANAGER - UI tema ve stil yönetimi
"""
from PyQt6.QtGui import QFont, QColor
from PyQt6.QtCore import QSize

class ThemeManager:
    """Tema ve stil yönetimi."""
    
    COLORS = {
        "primary": "#8e44ad",
        "accent": "#00d1ff",
        "background": "#0b0b0b",
        "surface": "#121212",
        "text": "#e0e0e0",
        "error": "#e74c3c",
        "success": "#27ae60",
        "warning": "#f39c12"
    }
    
    FONTS = {
        "title": QFont("Segoe UI", 16, QFont.Weight.Bold),
        "subtitle": QFont("Segoe UI", 12, QFont.Weight.Bold),
        "body": QFont("Segoe UI", 10),
        "small": QFont("Segoe UI", 9)
    }
    
    SIZES = {
        "icon": QSize(24, 24),
        "button": QSize(100, 40),
        "slider": QSize(300, 50)
    }
    
    @staticmethod
    def get_color(name: str) -> str:
        """Renk al."""
        return ThemeManager.COLORS.get(name, "#e0e0e0")
    
    @staticmethod
    def get_font(name: str) -> QFont:
        """Font al."""
        return ThemeManager.FONTS.get(name, ThemeManager.FONTS["body"])
