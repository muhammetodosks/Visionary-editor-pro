"""
ANIMATIONS - Smooth UI transitions
"""
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, Qt
from PyQt6.QtWidgets import QWidget

class SmoothAnimation:
    """Smooth animasyon utilities."""
    
    @staticmethod
    def slide_in(widget: QWidget, duration=300):
        """Widget'ı kaydır."""
        anim = QPropertyAnimation(widget, b"geometry")
        anim.setDuration(duration)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        return anim
    
    @staticmethod
    def fade_in(widget: QWidget, duration=300):
        """Widget'ı belirt."""
        anim = QPropertyAnimation(widget, b"windowOpacity")
        anim.setDuration(duration)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.InOutQuad)
        return anim
