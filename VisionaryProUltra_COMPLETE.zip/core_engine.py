"""
CORE ENGINE - Master Lifecycle Manager
Tüm thread'lerin yaşam döngüsünü ve hata yönetimini kontrol eder.
"""
import threading
import time
import queue
import logging
import traceback
from enum import Enum
from dataclasses import dataclass
from typing import Callable, Optional

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("CoreEngine")

class EngineState(Enum):
    STOPPED = 0
    INITIALIZING = 1
    RUNNING = 2
    PAUSED = 3
    SHUTTING_DOWN = 4
    ERROR = 5

@dataclass
class EngineStats:
    state: EngineState
    uptime: float
    errors: int
    last_error: Optional[str]
    thread_count: int

class CoreEngine:
    """Master engine untuk lifecycle management."""
    
    def __init__(self):
        self.state = EngineState.STOPPED
        self.threads = {}
        self.event_loop = threading.Event()
        self.lock = threading.RLock()
        self.start_time = None
        self.error_count = 0
        self.last_error = None
        self.shutdown_event = threading.Event()
        
    def register_thread(self, name: str, target: Callable, args=(), daemon=True):
        """Thread'i kaydet ve başlat."""
        with self.lock:
            if name in self.threads:
                logger.warning(f"Thread {name} zaten kayıtlı, atlaniyor")
                return False
            
            thread = threading.Thread(target=self._thread_wrapper, args=(name, target, args), daemon=daemon)
            self.threads[name] = {"thread": thread, "status": "created"}
            thread.start()
            logger.info(f"Thread '{name}' başlatıldı")
            return True
    
    def _thread_wrapper(self, name: str, target: Callable, args: tuple):
        """Thread'in hata yönetimi ile sarılmış versiyonu."""
        try:
            with self.lock:
                self.threads[name]["status"] = "running"
            target(*args)
        except Exception as e:
            self._handle_thread_error(name, e)
        finally:
            with self.lock:
                self.threads[name]["status"] = "stopped"
    
    def _handle_thread_error(self, name: str, error: Exception):
        """Thread hatasını kontrol et ve logla."""
        with self.lock:
            self.error_count += 1
            self.last_error = f"{name}: {str(error)}"
            self.state = EngineState.ERROR
        
        logger.error(f"Thread '{name}' hata: {str(error)}")
        logger.error(traceback.format_exc())
    
    def start(self):
        """Engine'i başlat."""
        with self.lock:
            self.state = EngineState.INITIALIZING
            self.start_time = time.time()
            self.shutdown_event.clear()
        logger.info("Core Engine başlatıldı")
    
    def stop(self):
        """Engine'i durdur ve cleanup yap."""
        with self.lock:
            if self.state == EngineState.STOPPED:
                return
            self.state = EngineState.SHUTTING_DOWN
        
        self.shutdown_event.set()
        logger.info("Tüm thread'ler kapatılıyor...")
        
        for name, thread_info in self.threads.items():
            thread = thread_info["thread"]
            if thread.is_alive():
                thread.join(timeout=5)
        
        with self.lock:
            self.state = EngineState.STOPPED
        logger.info("Core Engine tamamen durduruldu")
    
    def get_stats(self) -> EngineStats:
        """Engine istatistiklerini döndür."""
        with self.lock:
            uptime = time.time() - self.start_time if self.start_time else 0
            return EngineStats(
                state=self.state,
                uptime=uptime,
                errors=self.error_count,
                last_error=self.last_error,
                thread_count=len(self.threads)
            )
    
    def is_running(self) -> bool:
        """Engine çalışıyor mu?"""
        with self.lock:
            return self.state == EngineState.RUNNING
    
    def set_state(self, state: EngineState):
        """Durumu değiştir."""
        with self.lock:
            self.state = state
