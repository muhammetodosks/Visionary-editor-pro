"""
UI ENGINE - Modern PyQt6 interface with smooth animations
"""
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from PyQt6.QtGui import *
import logging

logger = logging.getLogger("UIEngine")

class UISignals(QObject):
    """Signal sistemi UI ve engine arasında thread-safe iletişim."""
    frame_updated = pyqtSignal(object)
    stats_updated = pyqtSignal(dict)
    detection_updated = pyqtSignal(dict)
    state_changed = pyqtSignal(str)

class UIEngine:
    """PyQt6 UI yöneticisi."""
    
    def __init__(self):
        self.signals = UISignals()
        self.lock = QMutex()
        self.theme = "dark"
        
        logger.info("UI Engine başlatıldı")
    
    def get_dark_stylesheet(self) -> str:
        """Modern karanlık tema."""
        return """
        QMainWindow {
            background-color: #0b0b0b;
            color: #e0e0e0;
        }
        QWidget {
            background-color: #121212;
            color: #e0e0e0;
        }
        QLabel {
            color: #e0e0e0;
        }
        QSlider::groove:horizontal {
            background: #333;
            height: 8px;
            margin: 2px 0;
            border-radius: 4px;
        }
        QSlider::handle:horizontal {
            background: #8e44ad;
            width: 18px;
            margin: -5px 0;
            border-radius: 9px;
        }
        QPushButton {
            background-color: #333;
            color: #e0e0e0;
            border: none;
            border-radius: 5px;
            padding: 10px;
            font-weight: bold;
        }
        QPushButton:hover {
            background-color: #8e44ad;
        }
        QPushButton:pressed {
            background-color: #6c3483;
        }
        QComboBox {
            background-color: #222;
            color: #e0e0e0;
            border: 1px solid #444;
            border-radius: 4px;
            padding: 5px;
        }
        QScrollArea {
            background-color: #151515;
            border: none;
        }
        """
    
    def emit_frame(self, frame):
        """Frame'i UI'ya gönder."""
        self.signals.frame_updated.emit(frame)
    
    def emit_stats(self, stats: dict):
        """İstatistikleri gönder."""
        self.signals.stats_updated.emit(stats)
    
    def emit_detection(self, detection: dict):
        """Algılama sonuçlarını gönder."""
        self.signals.detection_updated.emit(detection)
